-----

Thanks for helping test out our mod! This file tells you how to get it running
and where you can give us feedback once you're done!

-----

GETTING STARTED:

1. Make sure you've run Minecraft 1.14.4 before. If not, open up the launcher and run it once.

2. Download and install this version of Minecraft Forge:
   https://maven.minecraftforge.net/net/minecraftforge/forge/1.14.4-28.2.0/forge-1.14.4-28.2.0-installer.jar

3. Go to your .minecraft folder. On windows, you can do this by pressing the windows button then searching %appdata%

4. Put the "animatronics-1.0.1.jar" file into the "mods" folder.

5. Put the "Animatronics Test World 1" and "Animatronics Test World 2" folders into the "saves" folder.

4. Open the Minecraft launcher, select the 1.14.4 version of forge, and press Play.

-----

FIGHTING THE MOBS:

To test out fighting the mobs we added to Minecraft, open the first
test world we provided and press one of the buttons to spawn one in!
The first test world lets you fight the mobs individually, and the
second test world lets you fight them in interesting combinations.

Once you've fought the mobs in both worlds, visit this link to
let us know what you thought of them!

https://forms.gle/PE8U6s1RRp53Dget6

Thanks for playing!

-----